﻿let rec productOfOdds number =
    let rec productTail currentProduct currentNumber =
        if currentNumber = 1 then
            currentProduct
        else
            let newProduct = if currentNumber % 2 <> 0 then currentProduct * currentNumber else currentProduct
            productTail newProduct (currentNumber - 2)
    
    productTail number number


let result = productOfOdds 11
printfn "The product of all odd numbers from 11 to 1 is: %d" result
