﻿let bidhan = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]

let trimmedBidhan = bidhan |> List.map (fun name -> name.Trim())

// Display the trimmed names
printfn "Trimmed names:"
printfn "%A" trimmedBidhan
