﻿let sequence = seq { 1 .. 700 }
let numbersList = Seq.toList sequence
let filteredNumbers = numbersList |> List.filter (fun x -> x % 7 <> 0 || x % 5 <> 0)
let sumOfFilteredNumbers = List.reduce (+) filteredNumbers
printfn "Sum of numbers not multiples of both 7 and 5: %d" sumOfFilteredNumbers
