﻿let names = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]
let filteredNames = names |> List.filter (fun name -> not (name.Contains("i")))

let concatenatedNames =
    filteredNames 
    |> List.fold (fun acc name -> if acc = "" then name else acc + " " + name) "" 


printfn "Concatenated names without 'I': %s" concatenatedNames
