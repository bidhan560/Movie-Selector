﻿let rec productOfList bidhan =
    let rec productTail bidhan acc =
        match bidhan with
        | [] -> acc
        | head :: tail -> productTail tail (acc * head)
    
    match bidhan with
    | [] -> 1 
    | _ -> productTail bidhan 1

let myList = [2; 3; 4; 5]
let result = productOfList myList

printfn "The product of the list elements is: %d" result
